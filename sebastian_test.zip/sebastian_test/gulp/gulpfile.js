var gulp  = require('gulp'),
	sass = require('gulp-sass'),
	autoprefixer = require('gulp-autoprefixer'),
	concat = require('gulp-concat'),
	cssminify = require('gulp-clean-css'),
	sourcemaps = require('gulp-sourcemaps'),
	browserSync = require('browser-sync').create(),
	plumber = require('gulp-plumber'),
	watch = require('gulp-watch');
var exec = require('child_process').exec;


var paths = {
	main: ['sass/main.scss'],
	sass: ['sass/**/*.scss'],
	cssLibs: ['node_modules/bootstrap-sass/assets/stylesheets/bootstrap.scss', 'node_modules/font-awesome/scss/font-awesome.scss'],
	bootstrapJS: ['node_modules/jquery/dist/jquery.js', 'node_modules/bootstrap-sass/assets/javascripts/bootstrap.js'],
	fonts: ['node_modules/font-awesome/fonts/fontawesome-webfont.eot', 'node_modules/font-awesome/fonts/fontawesome-webfont.svg', 
	'node_modules/font-awesome/fonts/fontawesome-webfont.ttf', 'node_modules/font-awesome/fonts/fontawesome-webfont.woff', 'node_modules/font-awesome/fonts/fontawesome-webfont.woff2']
}


gulp.task('styles', function(){
	gulp.src(paths.main)
		.pipe(plumber())
		.pipe(sourcemaps.init())
		.pipe(sass({errLogToConsole: true}))
		.pipe(autoprefixer('last 2 versions'))
		.pipe(sourcemaps.write())
		.pipe(gulp.dest('../app/css'))
		.pipe(browserSync.reload({
	      stream: true
	    }))
});



gulp.task('cssLib', function(){
	gulp.src(paths.cssLibs)
		.pipe(sass())
		.pipe(concat('cssLibs.css'))
		.pipe(cssminify())
		.pipe(autoprefixer('last 2 versions'))
		.pipe(gulp.dest('../app/css'))
});


gulp.task('jsLib', function(){
	gulp.src(paths.bootstrapJS)
		.pipe(concat('jsLibs.js'))
		.pipe(gulp.dest('../app/js'))
});


gulp.task('fonts', function(){
	gulp.src(paths.fonts)
		.pipe(gulp.dest('../app/fonts'))
});


gulp.task('browserSync', function() {
  browserSync.init({
    server: "../app",
    port: 8000
  })
});


gulp.task('default', function() {
	gulp.watch(paths.sass, ['styles', 'browserSync']);
	gulp.watch(paths.sass).on('change', browserSync.reload);
});


