

$(document).ready(function() {

	// Read csv file and begin call a processing function to create cards
    $.ajax({
        url: "../js/candidates.csv",
        dataType: "text",
        success: function(data) {

        	createCards(data);
        	
        }
    });
});

//Array that will hold the candidates' information to fill up the confirmation modal
var candidatesModal = [];

function createCards(data){

			//Array that holds the data split into rows
        	var candidates_data = data.split(/\r\n|\n/);

        	//Target row in which cards will be appended
        	var row = $('#candidates-section').find('.row');

        	//Forloop starting on the second row straight into the candidates (1st row is the titles only)
        	for(var i = 1; i < candidates_data.length; i++){

        		//Read only the rows that have data in them. Last row is always empty
        		if(candidates_data[i]){

        			//Create a bootstrap column
		    		var col = $('<div />', {
				        "class": 'col-md-3 col-sm-6',
			        })
		    		//Append to new column to the row
		        	row.append(col);

		        	//Crate the card with all appripriate classes and the call to toggle in the modal
			        var card = $('<a />', {
			        	"class": 'candidate-card',
			        	"id": 'candidate-' + i,
			        	"href": "#candidate-selected",
			        	"role": "button",
			        	"data-toggle": "modal"
			        });

			        //Append the card to the column
			        col.append(card);

			        //Create the container for the image
			        var cardImgContainer = $('<div />', {
			        	"class": "candidate-img-container"
			        	});

			        //Create image icon with fontawesome and a wrapping div
			        var candidateImg = $('<div />', {
			        	"class": "candidate-img"
			        })

			        var img = $('<i />', {
			        	"class": "fa fa-user"
			        })

			        //Put img inside container and container inside the card
			        candidateImg.append(img);
			        cardImgContainer.append(candidateImg);
			        card.append(cardImgContainer);

			         // //Collect all candidates in the global array using splitter function which stops the spliting using the coma until the last column where text containing the comas is
			         candidatesModal[i-1] = spliter(candidates_data[i], /,/g, 4);

			        //Store single instances of the candidates
				        var candidateInfo = candidates_data[i].split(',');

			        //Fill up the body of the card section

			        //Create the container body
			        var cardBody = $('<div />', {
			        	"class": "candidate-body",
			        })

			        //Add the name title
			        var candidateName = $('<h3 />', {
			        	"text": candidateInfo[0] + " " + candidateInfo[1],
			        })

			        cardBody.append(candidateName);
			        card.append(cardBody);

			        //Get the party and add it to the body
			        var candidateParty = $("<span><strong>Party:</strong><br />" + candidateInfo[2] + "</span>");
			        cardBody.append(candidateParty);

			        //Get the district and add it to the body
			        var candidateDistrict = $("<span><strong>Electoral District:</strong><br />" + candidateInfo[3] + "</span>");
					cardBody.append(candidateDistrict);

					//Add the input radio 
					var input = $('<input />', {
						"value": "candidate-" + i,
						"class": "checkbox-field",
						"type": "radio"
					});
					card.append(input);

					//Add a button as a span for UI purposes
					var button = $('<span />', {
						"class": "btn btn-primary",
						"text": "select candidate",
					}) 
					card.append(button);
				
        		}
        	}  

        	//Checks when form has been submitted
        	var submitted = false;

        	//Add event listener after creating cards to change the checkboxes states and fillup modal
        	$('.candidate-card').click(function(){
        		//if form has not been submitted
        		if(!submitted){
        			//Allow to check radio buttons
	        		fillModal($('.candidate-card').index($(this)));
					var thisCheckbox = $(this).find('.checkbox-field');
					thisCheckbox.attr('checked', true);
					$('.checkbox-field').not(thisCheckbox).attr('checked', false); 
				}
			})


			function fillModal(candidateIndex){

				$('#candidate-selected').find('.candidate-name').html('The candidate you have selected is: <span class="text-primary">' + candidatesModal[candidateIndex][0] + " " + candidatesModal[candidateIndex][1] + "</span>");
				$('#candidate-selected').find('.candidate-party').html("<strong>The candidate's party is: </strong>" + candidatesModal[candidateIndex][2]);
				$('#candidate-selected').find('.candidate-district').html("<strong>The candidate's Electoral District: </strong>" + candidatesModal[candidateIndex][3]);
				$('#candidate-selected').find('.candidate-bio').html("<strong>Candidate's Bio: </strong>" + candidatesModal[candidateIndex][4]);
			}


		//Splitter function, taken from: https://stackoverflow.com/questions/29998343/limiting-the-times-that-split-splits-rather-than-truncating-the-resulting-ar
		function spliter(str, sep, n) {
			//Temp array
		    var out = [];

		    //This while loop iterates through string slicing until n is < 0. Thus, splitting that many times
		    while(n--){ 
		    	//Add the string to the temp array
		    	out.push(str.slice(sep.lastIndex, sep.exec(str).index));
		    }

		    //Add last string fully by adding last string fully without spliing anymore
		    out.push(str.slice(sep.lastIndex));

		    //return temp
		    return out;
		}

		$('#close-modal').click(function(){
			$('.checkbox-field').each(function() {
				$('.checkbox-field').attr('checked', false);
			})	
		})

	//On submit
   	$('#vote-confirm').click(function(e) {
   		//prevent submit
	    submitted = true;

	    //Preven modal from being called again during animation out
	    $(".candidate-card").removeAttr("href");

	    //Close modal
	    $('#candidate-selected').modal('toggle');

	    //Fadeout cards
	    setTimeout( function () {
		    $('#candidates-section').addClass('animation-out');
		}, 1000);

	    //Fade in confirmation
	    setTimeout( function () {
		    $('#confirmation').addClass('animation-in');
		}, 2000);

	    //submit form
	    setTimeout( function () { 
	        $('#from-main').submit();
	    }, 4000);
	});
}





